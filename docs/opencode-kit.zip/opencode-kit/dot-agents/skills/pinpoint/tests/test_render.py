"""Tests for render.py - normalize AI responses into the HTML intermediate
representation (IR): markdown -> block html, raw html -> well-formed fragment,
image -> wrapped page. IR at rest is clean: no ids, no annotations.
"""

import xml.etree.ElementTree as ET
from pathlib import Path

import pytest

import render
from render import (
    doc_document,
    image_page,
    normalize_html_fragment,
    render_blocks,
    slugify,
    split_blocks,
    xml_safe,
)


def body_parses(body_html: str) -> ET.Element:
    return ET.fromstring(f'<html><body>{body_html}</body></html>')


class TestSplitBlocks:
    def test_kinds(self):
        md = "\n".join([
            "# Title",
            "",
            "Intro paragraph.",
            "",
            "- one",
            "- two",
            "",
            "1. first",
            "2. second",
            "",
            "> quoted",
            "> more",
            "",
            "```python",
            "a = 1",
            "",
            "b = 2",
            "```",
            "",
            "| a | b |",
            "|---|---|",
            "| 1 | 2 |",
            "",
            "---",
            "",
            "Final para.",
        ])
        blocks = split_blocks(md)
        kinds = [b.kind for b in blocks]
        assert kinds == [
            'heading', 'para', 'ul', 'ol', 'quote', 'code', 'table', 'hr', 'para',
        ]

    def test_loose_list_stays_one_block(self):
        md = "- one\n\n- two\n\n- three\n"
        blocks = split_blocks(md)
        assert len(blocks) == 1
        assert blocks[0].kind == 'ul'

    def test_code_fence_spans_blank_lines(self):
        md = "```\na\n\nb\n```\n"
        blocks = split_blocks(md)
        assert len(blocks) == 1
        assert blocks[0].kind == 'code'

    def test_captures_language(self):
        blocks = split_blocks("```js\nx\n```\n")
        assert blocks[0].lang == 'js'


class TestRenderBlocks:
    def test_basic_structure(self):
        md = "# Title\n\nHello **world**.\n"
        body = render_blocks(md)
        assert '<h1>Title</h1>' in body
        assert '<p>Hello <strong>world</strong>.</p>' in body

    def test_no_ids_at_rest(self):
        body = render_blocks("# T\n\n- a\n- b\n\n```python\nx = 1\n```\n")
        assert ' id=' not in body

    def test_code_lines_are_spans(self):
        body = render_blocks("```python\na = 1\nb < 2\n```")
        assert '<pre' in body and 'data-lang="python"' in body
        assert '<span class="line">a = 1</span>' in body
        assert 'b &lt; 2' in body
        assert body.count('<span class="line">') == 2

    def test_empty_code_line_has_placeholder(self):
        body = render_blocks("```\na\n\nb\n```")
        assert body.count('<span class="line">') == 3

    def test_table_renders(self):
        md = "| a | b |\n|---|---|\n| 1 | 2 |\n"
        body = render_blocks(md)
        assert '<table>' in body and '<td>1</td>' in body

    def test_inline_markdown_in_paragraph(self):
        body = render_blocks("See [docs](http://x) and `code`.\n")
        assert '<a href="http://x">docs</a>' in body
        assert '<code>code</code>' in body

    def test_output_is_xml_safe(self):
        md = "AT&T <tag> &nbsp; &mdash; end\n"
        body = render_blocks(md)
        body_parses(body)

    def test_blockquote_renders(self):
        body = render_blocks("> wisdom\n")
        assert '<blockquote>' in body


class TestDiagramBlocks:
    def test_mermaid_becomes_diagram_figure(self):
        md = "```mermaid\nflowchart LR\nA --> B\n```\n"
        body = render_blocks(md)
        assert '<figure class="pp-diagram" data-lang="mermaid">' in body
        assert '<div class="line">flowchart LR</div>' in body
        assert '<div class="line">A --&gt; B</div>' in body
        assert '<pre' not in body
        assert '<span' not in body

    def test_blank_line_gets_placeholder(self):
        md = "```mermaid\ngraph TD\n\nA --> B\n```\n"
        body = render_blocks(md)
        assert body.count('<div class="line">') == 3
        assert '<div class="line">\u00a0</div>' in body

    def test_lang_matched_case_insensitively(self):
        body = render_blocks("```Mermaid\npie\n```\n")
        assert 'data-lang="mermaid"' in body
        assert '<figure class="pp-diagram"' in body

    def test_no_ids_at_rest(self):
        body = render_blocks("```mermaid\nA --> B\n```\n")
        assert ' id=' not in body

    def test_output_is_xml_safe(self):
        md = "```mermaid\nflowchart LR\nA[Draft & plan] --> B{Review}\n```\n"
        body_parses(render_blocks(md))

    def test_regular_code_stays_a_code_block(self):
        body = render_blocks("```python\nx = 1\n```\n")
        assert '<pre' in body and 'data-lang="python"' in body
        assert '<figure' not in body


class TestMockupFigures:
    def test_mockup_becomes_figure(self):
        md = '```mockup\n<button style="color: red">Save</button>\n```\n'
        body = render_blocks(md)
        assert '<figure class="pp-diagram" data-lang="mockup">' in body
        assert '<div class="line">&lt;button' in body
        assert '<pre' not in body

    def test_svg_becomes_figure(self):
        md = '```svg\n<circle cx="10" cy="10" r="5"/>\n```\n'
        body = render_blocks(md)
        assert '<figure class="pp-diagram" data-lang="svg">' in body
        assert '<div class="line">&lt;circle' in body
        assert '<pre' not in body

    def test_html_lang_stays_a_code_block(self):
        # ```html is a code listing (deterministic semantics); only the
        # explicit mockup/svg fence languages are drawn figures.
        body = render_blocks("```html\n<div>x</div>\n```\n")
        assert '<pre' in body and 'data-lang="html"' in body
        assert '<figure' not in body

    def test_mockup_source_is_escaped_not_live(self):
        # The IR stores the source as text; injection happens client-side.
        md = '```mockup\n<script>alert(1)</script>\n```\n'
        body = render_blocks(md)
        body_parses(body)
        assert '<script>' not in body
        assert '&lt;script&gt;' in body

    def test_no_ids_at_rest(self):
        # The source text keeps its `id=` characters (escaped), but no
        # element in the IR carries an actual id attribute.
        root = body_parses(render_blocks('```mockup\n<div id="x">a</div>\n```\n'))
        assert all(el.get('id') is None for el in root.iter())


class TestXmlSafe:
    def test_named_entities_become_numeric(self):
        assert xml_safe('a&nbsp;b') == 'a&#160;b'
        assert xml_safe('x&mdash;y') == 'x&#8212;y'

    def test_xml_native_entities_untouched(self):
        assert xml_safe('a&amp;b') == 'a&amp;b'
        assert xml_safe('a&lt;b') == 'a&lt;b'

    def test_bare_ampersand_escaped(self):
        assert xml_safe('AT&T') == 'AT&amp;T'

    def test_numeric_refs_untouched(self):
        assert xml_safe('&#160;') == '&#160;'


class TestNormalizeHtmlFragment:
    def test_fixes_void_elements_and_closes_all_tags(self):
        raw = '<p>two<br>three<img src="a.png">'
        out = normalize_html_fragment(raw)
        body_parses(out)
        assert '<br/>' in out
        assert '<img src="a.png"/>' in out
        assert 'three' in out

    def test_strips_script(self):
        out = normalize_html_fragment('<p>ok</p><script>alert(1)</script>')
        assert 'script' not in out and '<p>ok</p>' in out

    def test_strips_event_handlers(self):
        out = normalize_html_fragment('<p onclick="evil()">hi</p>')
        assert 'onclick' not in out and '<p>hi</p>' in out

    def test_strips_js_urls(self):
        out = normalize_html_fragment('<a href="javascript:evil()">x</a>')
        assert 'javascript' not in out

    def test_strips_iframe_object_embed(self):
        out = normalize_html_fragment('<iframe src="x"></iframe><object></object>')
        assert 'iframe' not in out and 'object' not in out

    def test_keeps_style_tag(self):
        out = normalize_html_fragment('<p>a</p><style>p{color:red}</style>')
        assert '<style>' in out

    def test_output_parses(self):
        raw = '<div><p>x<div>y</div><hr><img src="i.png"></div>'
        body_parses(normalize_html_fragment(raw))


class TestImagePage:
    def test_wraps_image(self):
        body = image_page('assets/chart.png', 'Chart')
        assert '<figure>' in body
        assert 'src="assets/chart.png"' in body
        assert '<figcaption>Chart</figcaption>' in body


class TestDocDocument:
    def test_full_document_parses_with_doctype(self):
        doc = doc_document('My Doc', '<p>hello</p>')
        assert doc.startswith('<!DOCTYPE html>')
        assert '<title>My Doc</title>' in doc
        # ET must parse the document body (DOCTYPE is skipped by expat).
        content = doc[len('<!DOCTYPE html>'):]
        root = ET.fromstring(content)
        assert root.find('.//p').text == 'hello'


class TestSlugify:
    def test_ascii(self):
        assert slugify('My Report!') == 'my-report'

    def test_chinese_falls_back_to_doc(self):
        assert slugify('设计文档') == 'doc'

    def test_mixed(self):
        assert slugify('Plan 方案 v2') == 'plan-v2'


class TestCli:
    def test_md_input_writes_doc(self, tmp_path: Path):
        src = tmp_path / 'notes.md'
        src.write_text('# Hi\n\nBody\n', encoding='utf-8')
        rc = render.main(['--out', str(tmp_path), str(src)])
        assert rc == 0
        out = tmp_path / 'docs' / 'notes.html'
        assert out.exists()
        assert '<h1>Hi</h1>' in out.read_text(encoding='utf-8')

    def test_html_input_normalized(self, tmp_path: Path):
        src = tmp_path / 'page.html'
        src.write_text('<p>one<p>two<br>end', encoding='utf-8')
        rc = render.main(['--out', str(tmp_path), str(src)])
        assert rc == 0
        out = tmp_path / 'docs' / 'page.html'
        text = out.read_text(encoding='utf-8')
        assert '<br/>' in text and '<p>two' in text

    def test_image_input_copies_asset(self, tmp_path: Path):
        src = tmp_path / 'chart.png'
        src.write_bytes(b'\x89PNG fake')
        rc = render.main(['--out', str(tmp_path), str(src)])
        assert rc == 0
        out = tmp_path / 'docs' / 'chart.html'
        assert out.exists()
        asset = tmp_path / 'assets' / 'chart.png'
        assert asset.read_bytes() == b'\x89PNG fake'
        assert 'src="../assets/chart.png"' in out.read_text(encoding='utf-8')

    def test_md_image_referenced_copied(self, tmp_path: Path):
        img = tmp_path / 'pic.png'
        img.write_bytes(b'PNG2')
        src = tmp_path / 'doc.md'
        src.write_text('# T\n\n![pic](pic.png)\n', encoding='utf-8')
        rc = render.main(['--out', str(tmp_path), str(src)])
        assert rc == 0
        assert (tmp_path / 'assets' / 'pic.png').read_bytes() == b'PNG2'
        out = (tmp_path / 'docs' / 'doc.html').read_text(encoding='utf-8')
        assert 'src="../assets/pic.png"' in out

    def test_bom_input_is_tolerated(self, tmp_path: Path):
        src = tmp_path / 'bom.md'
        src.write_bytes('\ufeff# Title\n\nBody\n'.encode('utf-8'))
        rc = render.main(['--out', str(tmp_path), str(src)])
        assert rc == 0
        out = (tmp_path / 'docs' / 'bom.html').read_text(encoding='utf-8')
        assert '<h1>Title</h1>' in out

    def test_refuses_to_overwrite_doc_with_pending_annotations(self, tmp_path: Path):
        src = tmp_path / 'notes.md'
        src.write_text('# Hi\n\nBody\n', encoding='utf-8')
        assert render.main(['--out', str(tmp_path), str(src)]) == 0
        # Mark an annotation on disk, then try to re-render the same name.
        doc = tmp_path / 'docs' / 'notes.html'
        doc.write_text(
            doc.read_text(encoding='utf-8').replace(
                '<h1>Hi</h1>',
                '<h1 id="_pp_0" data-edit-target="true" data-edit-annotation="keep me">Hi</h1>',
            ),
            encoding='utf-8',
        )
        rc = render.main(['--out', str(tmp_path), str(src)])
        assert rc != 0
        assert 'keep me' in doc.read_text(encoding='utf-8')

    def test_refuses_to_render_when_master_exists(self, tmp_path: Path):
        # The doc migrated to a master (or was created as one): the name
        # belongs to the master, a same-stem .html would be shadowed.
        src = tmp_path / 'notes.md'
        src.write_text('# Hi\n\nBody\n', encoding='utf-8')
        (tmp_path / 'docs').mkdir(parents=True)
        (tmp_path / 'docs' / 'notes.md').write_text(
            '# Hi\n\n<!-- pp: still discussing -->\nBody\n', encoding='utf-8')
        rc = render.main(['--out', str(tmp_path), str(src)])
        assert rc != 0
        assert not (tmp_path / 'docs' / 'notes.html').exists()

    def test_refuses_to_render_when_converged_master_exists(self, tmp_path: Path):
        # Even a converged master owns the name (server lists it; a new
        # .html would never show up).
        src = tmp_path / 'notes.md'
        src.write_text('# Hi\n\nBody\n', encoding='utf-8')
        (tmp_path / 'docs').mkdir(parents=True)
        (tmp_path / 'docs' / 'notes.md').write_text('# Hi\n\nBody\n', encoding='utf-8')
        rc = render.main(['--out', str(tmp_path), str(src)])
        assert rc != 0
        assert not (tmp_path / 'docs' / 'notes.html').exists()

    def test_clean_doc_can_be_rerendered_with_new_name(self, tmp_path: Path):
        src = tmp_path / 'notes.md'
        src.write_text('# Hi\n\nBody\n', encoding='utf-8')
        assert render.main(['--out', str(tmp_path), str(src)]) == 0
        rc = render.main(['--out', str(tmp_path), '--name', 'notes-v2', str(src)])
        assert rc == 0
        assert (tmp_path / 'docs' / 'notes-v2.html').exists()

    def test_name_override(self, tmp_path: Path):
        src = tmp_path / 'notes.md'
        src.write_text('x\n', encoding='utf-8')
        rc = render.main(['--out', str(tmp_path), '--name', 'review-round-1', str(src)])
        assert rc == 0
        assert (tmp_path / 'docs' / 'review-round-1.html').exists()
