#!/usr/bin/env python3
"""
pinpoint - Local Preview Server Helpers

Adapted from ppt-master's scripts/server_common.py (battle-tested there).
Owns browser dispatch, the cross-platform process-liveness check and the
claim/read/release lock logic for the local Flask editor server.

Usage:
    from server_common import find_free_port, validate_port

Dependencies:
    None (only uses standard library)
"""

import base64
import importlib
import json
import logging
import os
import platform
import shutil
import socket
import subprocess
import sys
import types
import webbrowser
from pathlib import Path
from typing import Optional


MIN_PORT = 1
MAX_PORT = 65535

DEFAULT_WORKSPACE_NAME = '.pinpoint'
SELF_IGNORE_CONTENT = '*\n'


def ensure_workspace(workspace: Path) -> None:
    """Create the workspace directory; guard the default name from git.

    The default ``.pinpoint`` workspace is runtime state dropped into the
    host project, so it ships a self-ignore ``.gitignore`` (content
    ``*``): nothing inside — this file included — can be committed by
    accident. A custom-named workspace is left alone; the user chose that
    directory and may want it tracked. Failure to write the guard is
    non-fatal.
    """
    workspace.mkdir(parents=True, exist_ok=True)
    if workspace.name != DEFAULT_WORKSPACE_NAME:
        return
    ignore_file = workspace / '.gitignore'
    if ignore_file.exists():
        return
    try:
        write_text_lf(ignore_file, SELF_IGNORE_CONTENT)
    except OSError:
        pass


def write_text_lf(path: Path, text: str) -> None:
    """Write ``text`` to ``path`` with LF newlines on every platform.

    Iron rule IR-1 (AGENTS.md): files this project produces must be
    byte-identical between Windows and macOS. ``Path.write_text`` uses
    ``newline=None``, which translates ``\\n`` to ``os.linesep`` (CRLF
    on Windows); ``newline=''`` disables the translation so the ``\\n``
    characters in ``text`` reach the file untouched. (``Path.write_text``
    grew a ``newline`` parameter only in Python 3.10; the project
    supports 3.9 — see references/editor.md.)
    """
    with open(path, 'w', encoding='utf-8', newline='') as fh:
        fh.write(text)


def import_or_install(
    module_name: str,
    pip_package: Optional[str] = None,
) -> types.ModuleType:
    """Import a third-party module, pip-installing it only on real failure.

    The healthy path never touches pip: this acts only when the import
    raises ``ModuleNotFoundError``. ``pip_package`` names the distribution
    when it differs from the import name (e.g. ``bs4`` ->
    ``beautifulsoup4``). If the install does not fix the import, the
    original error propagates unchanged.
    """
    try:
        return importlib.import_module(module_name)
    except ModuleNotFoundError:
        pass

    package = pip_package or module_name
    print(
        f'[pinpoint] module {module_name!r} missing; '
        f'installing {package} via pip ...',
        file=sys.stderr,
        flush=True,
    )
    subprocess.check_call([
        sys.executable, '-m', 'pip', 'install',
        '--disable-pip-version-check', '--quiet', package,
    ])
    return importlib.import_module(module_name)


# Windows PowerShell as mounted inside WSL; probed when ``[interop]
# appendWindowsPath=false`` keeps interop but drops Windows dirs from PATH.
WSL_POWERSHELL = '/mnt/c/Windows/System32/WindowsPowerShell/v1.0/powershell.exe'


def _wsl_powershell() -> Optional[str]:
    """Return the Windows PowerShell path under WSL, else ``None``."""
    if 'microsoft' not in platform.release().lower():
        return None
    found = shutil.which('powershell.exe')
    if found:
        return found
    return WSL_POWERSHELL if os.access(WSL_POWERSHELL, os.X_OK) else None


def open_preview_browser(
    url: str, logger: Optional[logging.Logger] = None,
) -> bool:
    """Ask the host OS to open a preview URL; visibility is unverified.

    ``BROWSER`` keeps its usual ``webbrowser`` meaning everywhere.
    Without it, WSL asks Windows PowerShell for the Windows default
    browser: WSL's ``gio`` may exist without an HTTP handler, and
    ``webbrowser`` reports success as soon as that child spawns. Every
    other host uses ``webbrowser`` unchanged.
    """
    log = logger or logging.getLogger(__name__)
    try:
        powershell = None if os.environ.get('BROWSER') else _wsl_powershell()
        if powershell:
            # Keep the URL as data: quotes, ampersands, non-ASCII text.
            encoded_url = base64.b64encode(url.encode('utf-8')).decode('ascii')
            script = (
                "$ErrorActionPreference = 'Stop'; "
                "$u = [Text.Encoding]::UTF8.GetString("
                "[Convert]::FromBase64String('" + encoded_url + "')); "
                "Start-Process -FilePath $u"
            )
            command = base64.b64encode(
                script.encode('utf-16le')).decode('ascii')
            result = subprocess.run(
                [powershell, '-NoProfile', '-NonInteractive',
                 '-EncodedCommand', command],
                capture_output=True, timeout=15, check=False,
            )
            if result.returncode:
                detail = result.stderr.decode('utf-8', errors='replace').strip()
                raise OSError(
                    f'PowerShell exited {result.returncode}: {detail}')
        elif not webbrowser.open(url):
            raise OSError('no browser accepted the URL')
        log.info('browser launch request accepted by OS: %s', url)
        return True
    except (OSError, subprocess.TimeoutExpired, webbrowser.Error) as exc:
        log.warning('browser launch failed: %s; open %s manually', exc, url)
        return False


def validate_port(port: int) -> int:
    """Return a valid TCP port, raising ``ValueError`` outside 1..65535."""
    if isinstance(port, bool) or not isinstance(port, int):
        raise ValueError('port must be an integer between 1 and 65535')
    if not MIN_PORT <= port <= MAX_PORT:
        raise ValueError(
            f'port must be between {MIN_PORT} and {MAX_PORT}: {port}')
    return port


def find_free_port(
    preferred: int, host: str = '127.0.0.1', span: int = 50,
) -> int:
    """Return the first bindable port from ``preferred`` through its scan span.

    The scan remains sequential so callers can keep 5050 as their preferred
    port and advance predictably when it is occupied. Invalid ports fail before
    probing, and an exhausted valid range raises ``RuntimeError`` instead of
    returning a port already known to be unavailable.

    The probe binds with a plain socket — no ``SO_REUSEADDR`` (issue 0022).
    ``SO_REUSEADDR`` means opposite things on the two platforms, and the
    probe must test exactly what the caller's real bind will do:

    * Windows: a listening socket that opted into reuse (every
      ``HTTPServer`` does, via ``allow_reuse_address = 1``) can be bound
      again by another reuse socket — two daemons then LISTEN on the same
      port and connections route unpredictably. A plain probe bind is
      refused instead, so occupied ports are skipped.
    * POSIX: reuse only bridges ``TIME_WAIT``, never a live listener, so
      the plain probe refuses occupied ports as well; its one collateral
      effect is that a ``TIME_WAIT`` port is also skipped and the scan
      drifts to the next port. That drift is accepted: a port still
      cooling down is not a port we want to hand out anyway.
    """
    preferred = validate_port(preferred)
    if isinstance(span, bool) or not isinstance(span, int) or span <= 0:
        raise ValueError(f'span must be a positive integer: {span}')

    last_port = min(preferred + span - 1, MAX_PORT)
    for port in range(preferred, last_port + 1):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as probe:
            try:
                probe.bind((host, port))
                return port
            except OSError:
                continue
    raise RuntimeError(
        f'no free TCP port on {host} in range {preferred}..{last_port}'
    )


# IR-1 (AGENTS.md rule 1): the single home for the listen-socket
# ``SO_REUSEADDR`` decision. ``socketserver``/``http.server`` servers
# consume this as their ``allow_reuse_address`` value.
#
# Windows: ``SO_REUSEADDR`` on a listen socket lets another reuse
# socket bind (and LISTEN) over it — the 0022 double-bind — so it
# stays off; a contested bind must fail loudly with ``EADDRINUSE``
# instead of silently creating a second listener.
# POSIX: ``SO_REUSEADDR`` only bridges ``TIME_WAIT`` (never a live
# listener), which quick restarts on the same port need, so it stays
# on.
LISTEN_REUSE_ADDRESS = os.name != 'nt'


def popen_detached(
    args: list[str],
    *,
    logger: Optional[logging.Logger] = None,
    **kwargs: object,
) -> subprocess.Popen:
    """Start a long-running child process detached from the caller.

    Windows hosts such as terminal sandboxes may place child processes in the
    caller's Job Object. ``CREATE_BREAKAWAY_FROM_JOB`` lets the local UI server
    survive after the launcher command returns; when that flag is forbidden, the
    function falls back to the previous detached-process flags.
    """
    supplied_env = kwargs.get('env')
    if supplied_env is None:
        kwargs.pop('env', None)
    else:
        kwargs['env'] = supplied_env

    if os.name != 'nt':
        return subprocess.Popen(args, start_new_session=True, **kwargs)

    base_flags = (
        subprocess.CREATE_NEW_PROCESS_GROUP | subprocess.DETACHED_PROCESS)
    breakaway_flag = getattr(
        subprocess, 'CREATE_BREAKAWAY_FROM_JOB', 0x01000000)
    try:
        return subprocess.Popen(
            args,
            creationflags=base_flags | breakaway_flag,
            **kwargs,
        )
    except OSError as exc:
        if logger is not None:
            logger.warning(
                'Windows process breakaway failed; falling back to detached '
                'process-group launch (%s)',
                exc,
            )
        return subprocess.Popen(args, creationflags=base_flags, **kwargs)


def process_alive(pid: object) -> bool:
    """Return True if a process with this pid is reachable.

    On POSIX, ``os.kill(pid, 0)`` succeeds when the process exists even without
    permission to signal it; ``PermissionError`` therefore still counts as
    alive. On Windows there is no ``os.kill(pid, 0)`` equivalent, so probe via
    ``OpenProcess`` + ``WaitForSingleObject``.
    """
    try:
        pid_int = int(pid)
    except (TypeError, ValueError):
        return False
    if pid_int <= 0:
        return False
    if os.name == 'nt':
        import ctypes
        import ctypes.wintypes

        kernel32 = ctypes.WinDLL('kernel32', use_last_error=True)
        kernel32.OpenProcess.argtypes = [
            ctypes.wintypes.DWORD,
            ctypes.wintypes.BOOL,
            ctypes.wintypes.DWORD,
        ]
        kernel32.OpenProcess.restype = ctypes.wintypes.HANDLE
        kernel32.WaitForSingleObject.argtypes = [
            ctypes.wintypes.HANDLE,
            ctypes.wintypes.DWORD,
        ]
        kernel32.WaitForSingleObject.restype = ctypes.wintypes.DWORD
        kernel32.CloseHandle.argtypes = [ctypes.wintypes.HANDLE]
        kernel32.CloseHandle.restype = ctypes.wintypes.BOOL

        process_query_limited_information = 0x1000
        synchronize = 0x00100000
        wait_timeout = 0x00000102
        wait_object_0 = 0x00000000
        wait_failed = 0xFFFFFFFF

        handle = kernel32.OpenProcess(
            process_query_limited_information | synchronize,
            False,
            pid_int,
        )
        if not handle:
            return ctypes.get_last_error() == 5  # ERROR_ACCESS_DENIED
        try:
            result = kernel32.WaitForSingleObject(handle, 0)
            if result == wait_timeout:
                return True
            if result in (wait_object_0, wait_failed):
                return False
            return False
        finally:
            kernel32.CloseHandle(handle)

    try:
        os.kill(pid_int, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    except OSError:
        return False
    return True


def read_lock(lock_file: Path) -> Optional[dict]:
    """Read a lock file, returning the lock dict or None if absent/corrupt."""
    try:
        data = json.loads(lock_file.read_text(encoding='utf-8'))
        return data if isinstance(data, dict) else None
    except (OSError, json.JSONDecodeError):
        return None


def lock_pid(lock: Optional[dict]) -> int:
    """Return a valid pid from a lock dict, or 0 if absent/corrupt."""
    if not lock:
        return 0
    raw_pid = lock.get('pid', 0)
    if isinstance(raw_pid, bool):
        return 0
    if isinstance(raw_pid, int):
        return raw_pid if raw_pid > 0 else 0
    if isinstance(raw_pid, str) and raw_pid.strip().isdigit():
        return int(raw_pid.strip())
    return 0


def claim_lock(lock_file: Path, port: int) -> Optional[dict]:
    """Try to claim the per-project preview slot.

    Returns ``None`` on success. If another live process already holds the
    slot, returns the existing lock dict (caller surfaces it as an error).
    A stale lock (pointing at a dead pid) is silently overwritten.
    """
    existing = read_lock(lock_file)
    if existing and process_alive(lock_pid(existing)):
        return existing
    lock_file.write_text(
        json.dumps({'pid': os.getpid(), 'port': port}),
        encoding='utf-8',
    )
    return None


def release_lock(lock_file: Path) -> None:
    """Best-effort cleanup: only delete the lock if it still names *us*."""
    try:
        current = read_lock(lock_file)
        if lock_pid(current) == os.getpid():
            lock_file.unlink(missing_ok=True)
    except OSError:
        pass


def clear_lock(lock_file: Path) -> None:
    """Best-effort cleanup for a lock already proven stale by the caller."""
    try:
        lock_file.unlink(missing_ok=True)
    except OSError:
        pass
